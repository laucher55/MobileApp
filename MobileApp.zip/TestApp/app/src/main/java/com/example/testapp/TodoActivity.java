package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class TodoActivity extends AppCompatActivity {
    private EditText editText;
    private Button btnAdd;
    private ListView listView;
    private ArrayList<String> itemList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo);

        editText = findViewById(R.id.todoText);
        btnAdd = findViewById(R.id.btAdd);
        listView = findViewById(R.id.todoList);

        itemList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itemList);
        listView.setAdapter(adapter);
    }

    public void addToList(View view) {
        String newItem = editText.getText().toString();
        if (!newItem.isEmpty()) {
            itemList.add(newItem);
            adapter.notifyDataSetChanged();
            editText.setText("");
        }
    }
}